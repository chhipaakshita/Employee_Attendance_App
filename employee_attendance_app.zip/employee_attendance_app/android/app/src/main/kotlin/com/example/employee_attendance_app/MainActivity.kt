package com.example.employee_attendance_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
