
class Constant{
  static const employeeTable = "employees";
  static const departmentTable = "departments";
  static const attendanceTable = " attendance";
}